# Ranking Algorithm Introduction

- Data and notebook for the [ranking algorithm article](https://towardsdatascience.com/ranking-algorithms-know-your-multi-criteria-decision-solving-techniques-20949198f23e)
- Dependency on `scikit-criteria==0.2.11` package. Note, there has been a code breaking change with version 0.5 of the package, consider using the `0.2.11` version for the shared code.
