.. _changelog:

==========================
Changelog
==========================

.. Here we render the CHANGELOG.md of the repository as a main page
.. include:: _dynamic/CHANGELOG.rst
