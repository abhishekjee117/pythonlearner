``skcriteria.pipeline`` module
==============================

.. automodule:: skcriteria.pipeline
   :members:
   :undoc-members:
   :show-inheritance:
