``skcriteria.core.data`` module
=================================

.. automodule:: skcriteria.core.data
   :members:
   :undoc-members:
   :show-inheritance:
