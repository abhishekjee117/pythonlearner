``skcriteria.core.dominance`` module
====================================

.. automodule:: skcriteria.core.dominance
   :members:
   :undoc-members:
   :show-inheritance:
