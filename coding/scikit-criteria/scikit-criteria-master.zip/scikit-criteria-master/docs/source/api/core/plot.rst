``skcriteria.core.plot`` module
===============================

.. automodule:: skcriteria.core.plot
   :members:
   :undoc-members:
   :show-inheritance:
