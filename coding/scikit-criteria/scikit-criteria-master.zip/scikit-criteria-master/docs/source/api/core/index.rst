``skcriteria.core`` package
============================

.. automodule:: skcriteria.core
   :members:
   :undoc-members:
   :show-inheritance:
   :ignore-module-all:

.. toctree::
   :maxdepth: 2
   :glob:

   *