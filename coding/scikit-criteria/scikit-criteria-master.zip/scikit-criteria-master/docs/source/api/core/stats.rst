``skcriteria.core.stats`` module
================================

.. automodule:: skcriteria.core.stats
   :members:
   :undoc-members:
   :show-inheritance:
