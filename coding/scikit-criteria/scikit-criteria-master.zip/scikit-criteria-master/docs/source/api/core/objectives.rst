``skcriteria.core.objectives`` module
=====================================

.. automodule:: skcriteria.core.objectives
   :members:
   :undoc-members:
   :show-inheritance:
