``skcriteria.core.methods`` module
==================================

.. automodule:: skcriteria.core.methods
   :members:
   :undoc-members:
   :show-inheritance:
