``skcriteria.utils.cmanagers`` module
======================================

.. automodule:: skcriteria.utils.cmanagers
   :members:
   :undoc-members:
   :show-inheritance:
