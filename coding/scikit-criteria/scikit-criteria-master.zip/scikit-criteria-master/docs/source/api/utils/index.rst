``skcriteria.utils`` package
============================

.. automodule:: skcriteria.utils
   :members:
   :undoc-members:
   :show-inheritance:
   :ignore-module-all:

.. toctree::
   :maxdepth: 2
   :glob:

   *