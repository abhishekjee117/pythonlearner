``skcriteria.utils.accabc`` module
==================================

.. automodule:: skcriteria.utils.accabc
   :members:
   :undoc-members:
   :show-inheritance:
