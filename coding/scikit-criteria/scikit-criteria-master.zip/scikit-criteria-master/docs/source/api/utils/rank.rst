``skcriteria.utils.rank`` module
================================

.. automodule:: skcriteria.utils.rank
   :members:
   :undoc-members:
   :show-inheritance:
