``skcriteria.utils.bunch`` module
=================================

.. automodule:: skcriteria.utils.bunch
   :members:
   :undoc-members:
   :show-inheritance:
