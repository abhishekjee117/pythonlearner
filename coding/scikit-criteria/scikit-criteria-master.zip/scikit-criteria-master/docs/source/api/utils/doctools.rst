``skcriteria.utils.doctools`` module
======================================

.. automodule:: skcriteria.utils.doctools
   :members:
   :undoc-members:
   :show-inheritance:
