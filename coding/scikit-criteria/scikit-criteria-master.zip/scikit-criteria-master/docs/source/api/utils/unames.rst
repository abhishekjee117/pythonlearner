``skcriteria.utils.unames`` module
=====================================

.. automodule:: skcriteria.utils.unames
   :members:
   :undoc-members:
   :show-inheritance:
