``skcriteria.utils.lp`` module
==============================

.. automodule:: skcriteria.utils.lp
   :members:
   :undoc-members:
   :show-inheritance:
