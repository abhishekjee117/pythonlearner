``skcriteria.utils.deprecate`` module
======================================

.. automodule:: skcriteria.utils.deprecate
   :members:
   :undoc-members:
   :show-inheritance:
