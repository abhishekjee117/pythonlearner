``skcriteria.madm.electre`` module
==================================

.. automodule:: skcriteria.madm.electre
   :members:
   :undoc-members:
   :show-inheritance:
