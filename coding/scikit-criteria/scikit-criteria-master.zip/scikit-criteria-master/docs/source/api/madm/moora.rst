``skcriteria.madm.moora`` module
================================

.. automodule:: skcriteria.madm.moora
   :members:
   :undoc-members:
   :show-inheritance:
