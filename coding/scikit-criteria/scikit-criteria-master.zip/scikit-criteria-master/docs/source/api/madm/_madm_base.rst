``skcriteria.madm._madm_base`` module
=====================================

.. automodule:: skcriteria.madm._madm_base
   :members:
   :undoc-members:
   :show-inheritance: