``skcriteria.madm`` package
===========================

.. automodule:: skcriteria.madm
   :members:
   :undoc-members:
   :show-inheritance:
   :ignore-module-all:

.. toctree::
   :maxdepth: 2
   :glob:

   *
