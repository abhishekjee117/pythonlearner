``skcriteria.madm.similarity`` module
=====================================

.. automodule:: skcriteria.madm.similarity
   :members:
   :undoc-members:
   :show-inheritance:
