``skcriteria.madm.simus`` module
================================

.. automodule:: skcriteria.madm.simus
   :members:
   :undoc-members:
   :show-inheritance:
