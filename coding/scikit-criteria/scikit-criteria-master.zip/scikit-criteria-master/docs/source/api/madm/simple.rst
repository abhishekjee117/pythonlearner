``skcriteria.madm.simple`` module
=================================

.. automodule:: skcriteria.madm.simple
   :members:
   :undoc-members:
   :show-inheritance:
