``skcriteria.cmp`` package
============================

.. automodule:: skcriteria.cmp
   :members:
   :undoc-members:
   :show-inheritance:
   :ignore-module-all:

.. toctree::
   :maxdepth: 2
   :glob:

   *