``skcriteria.cmp.ranks_cmp`` module
===================================

.. automodule:: skcriteria.cmp.ranks_cmp
   :members:
   :undoc-members:
   :show-inheritance:
