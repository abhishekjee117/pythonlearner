``skcriteria.datasets`` package
===============================

.. automodule:: skcriteria.datasets
   :members:
   :undoc-members:
   :show-inheritance:
   :ignore-module-all:

.. .. toctree::
..    :maxdepth: 2
..    :glob:

..    *