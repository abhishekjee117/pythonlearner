``skcriteria.preprocessing`` package
====================================

.. automodule:: skcriteria.preprocessing
   :members:
   :undoc-members:
   :show-inheritance:
   :ignore-module-all:

.. toctree::
   :maxdepth: 2
   :glob:

   *