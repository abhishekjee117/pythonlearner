``skcriteria.preprocessing.impute`` module
===========================================

.. automodule:: skcriteria.preprocessing.impute
   :members:
   :undoc-members:
   :show-inheritance:
