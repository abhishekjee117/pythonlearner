``skcriteria.preprocessing.filters`` module
=============================================

.. automodule:: skcriteria.preprocessing.filters
   :members:
   :undoc-members:
   :show-inheritance:
