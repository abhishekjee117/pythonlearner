``skcriteria.preprocessing.push_negatives`` module
==================================================

.. automodule:: skcriteria.preprocessing.push_negatives
   :members:
   :undoc-members:
   :show-inheritance:
