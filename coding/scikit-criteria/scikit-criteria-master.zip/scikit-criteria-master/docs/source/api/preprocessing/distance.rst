``skcriteria.preprocessing.distance`` module
============================================

.. warning::
    This module is deprecated.

.. automodule:: skcriteria.preprocessing.distance
   :members:
   :undoc-members:
   :show-inheritance:
