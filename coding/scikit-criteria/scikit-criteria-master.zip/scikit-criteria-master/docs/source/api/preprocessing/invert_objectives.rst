``skcriteria.preprocessing.invert_objectives`` module
======================================================

.. automodule:: skcriteria.preprocessing.invert_objectives
   :members:
   :undoc-members:
   :show-inheritance:
