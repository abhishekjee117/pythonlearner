``skcriteria.preprocessing.scalers`` module
===========================================

.. automodule:: skcriteria.preprocessing.scalers
   :members:
   :undoc-members:
   :show-inheritance:
