``skcriteria.preprocessing.increment`` module
=============================================

.. automodule:: skcriteria.preprocessing.increment
   :members:
   :undoc-members:
   :show-inheritance:
