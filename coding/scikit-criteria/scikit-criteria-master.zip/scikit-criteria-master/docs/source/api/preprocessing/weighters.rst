``skcriteria.preprocessing.weighters`` module
=============================================

.. automodule:: skcriteria.preprocessing.weighters
   :members:
   :undoc-members:
   :show-inheritance:
