``skcriteria.preprocessing._preprocessing_base`` module
=======================================================

.. automodule:: skcriteria.preprocessing._preprocessing_base
   :members:
   :undoc-members:
   :show-inheritance: