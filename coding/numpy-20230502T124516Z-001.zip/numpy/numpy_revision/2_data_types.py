'''
DATA TYPES
'''
import numpy as np

dt = np.dtype(np.int32)
print(dt)
dt = np.dtype('i4')
print(dt)
