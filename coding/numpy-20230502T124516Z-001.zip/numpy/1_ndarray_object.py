# ---PANDAS NUMPY - NDARRAY---

import numpy as np

print("\nCreating a basic numpy 1-d array...")
a = np.array([1,2,3])
print("The numpy ndarray is:")
print(a)
print("The type of the numpy 1-d array is:")
print(type(a))

print("\nCreating a basic numpy 2-d array...")
a = np.array([[1,2],[3,4]])
print("The numpy 2-d array is:")
print(a)
print("The type of the numpy 2-d array is:")
print(type(a))

print("\nCreating a basic numpy 2-d array with a specific dimension...")
a = np.array([1,2,3,4,5], ndmin=2)
print("The numpy 2-d array is:")
print(a)
print("The type of the numpy 2-d array is:")
print(type(a))

print("\nCreating a basic numpy 2-d array with a complex data type...")
a = np.array([1,2,3], dtype=complex)
print("The numpy 2-d array is:")
print(a)
print("The type of the numpy 2-d array is:")
print(type(a))
